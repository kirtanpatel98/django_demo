from django.apps import AppConfig


class TextfieldConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'textfield'
