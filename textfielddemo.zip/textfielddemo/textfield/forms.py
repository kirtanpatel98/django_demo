from django import forms


class TemplateForm(forms.Form):
    title = forms.CharField(max_length=245, label="Enter here")
