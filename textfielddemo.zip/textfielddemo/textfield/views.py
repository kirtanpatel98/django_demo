from django.shortcuts import render
from django.http import HttpResponse
from .forms import TemplateForm

# Create your views here.


def NewPage(request, name):
    return render(request, 'newpage.html', {'msg': name})


def HomePage(request):
    if request.method == 'POST':
        form = TemplateForm(request.POST)
        if form.is_valid():
            message = form.cleaned_data['title']
            data = {
                'form': form,
                'message': message
            }
    else:
        form = TemplateForm()
        data = {
            'form': form,
        }
    return render(request, 'homepage.html', data)
